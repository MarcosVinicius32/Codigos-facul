
package projeto_numerointeiro;
import javax.swing.JOptionPane;

public class Projeto_numerointeiro {

    
    public static void main(String[] args) {
       int num1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o numero inteiro"));
       
        if(num1%2== 1){
    JOptionPane.showMessageDialog(null,"o numero: " + num1 + " e impar");
    
}
        else{
        JOptionPane.showMessageDialog(null,"o numero: " + num1 + " e par");
    }
}
}