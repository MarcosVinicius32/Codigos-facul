let data_hora = new Date()
  let hora = data_hora.getHours();
  if(hora>18){
    alert("boa noite");
  }