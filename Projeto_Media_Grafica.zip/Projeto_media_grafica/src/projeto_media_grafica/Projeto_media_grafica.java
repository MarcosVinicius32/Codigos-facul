
package projeto_media_grafica;
import javax.swing.JOptionPane;

public class Projeto_media_grafica {

    public static void main(String[] args) {
       int nota1 = Integer.parseInt(JOptionPane.showInputDialog("Digite nota1"));
       int nota2 = Integer.parseInt(JOptionPane.showInputDialog("Digite nota1"));
       int nota3 = Integer.parseInt(JOptionPane.showInputDialog("Digite nota1"));
       int nota4 = Integer.parseInt(JOptionPane.showInputDialog("Digite nota1"));
       int media = (nota1+nota2+nota3+nota4)/4;
       if (media >=6){
           JOptionPane.showMessageDialog(null,"APROVADO");
       }
       else if(media >4 && media <=5){
       JOptionPane.showMessageDialog(null,"RECUPERAÇÃO");
       }
       else{
       JOptionPane.showMessageDialog(null,"Reprovado");
       }
       
    }
    
}
